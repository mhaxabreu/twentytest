import React from "react";
import { TbHome } from "react-icons/tb";
const IconHome = (props) => <TbHome size={14} />;

export default IconHome;
