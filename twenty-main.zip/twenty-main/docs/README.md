# Documentation

The docs here are managed through [Docusaurus 2](https://docusaurus.io/).

We recommend you go directly to the [statically generated website](https://docs.twenty.com) rather than read them here.