import { createContext } from 'react';

export const RowIndexContext = createContext<number>(0);
