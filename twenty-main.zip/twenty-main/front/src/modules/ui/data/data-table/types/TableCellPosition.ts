export type TableCellPosition = {
  row: number;
  column: number;
};
