import { createContext } from 'react';

export const TableRecoilScopeContext = createContext<string | null>(null);
