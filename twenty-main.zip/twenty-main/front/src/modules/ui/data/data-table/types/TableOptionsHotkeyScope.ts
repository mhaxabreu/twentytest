export enum TableOptionsHotkeyScope {
  Dropdown = 'table-options-dropdown',
}
