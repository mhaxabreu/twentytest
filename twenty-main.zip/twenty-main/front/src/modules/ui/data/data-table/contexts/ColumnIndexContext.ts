import { createContext } from 'react';

export const ColumnIndexContext = createContext<number>(0);
