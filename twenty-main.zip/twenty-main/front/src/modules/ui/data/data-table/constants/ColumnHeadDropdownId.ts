export const ColumnHeadDropdownId = 'table-head-options';
