import { createContext } from 'react';

export const RowIdContext = createContext<string | null>(null);
