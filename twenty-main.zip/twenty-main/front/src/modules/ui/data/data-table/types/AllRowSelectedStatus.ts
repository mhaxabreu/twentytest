export type AllRowsSelectedStatus = 'none' | 'some' | 'all';
