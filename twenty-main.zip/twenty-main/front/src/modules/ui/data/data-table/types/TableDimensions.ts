export type TablePosition = {
  numberOfRows: number;
  numberOfColumns: number;
};
