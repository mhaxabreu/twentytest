import { createContext } from 'react';

export const CompanyBoardViewBarRecoilScopeContext = createContext<
  string | null
>(null);
