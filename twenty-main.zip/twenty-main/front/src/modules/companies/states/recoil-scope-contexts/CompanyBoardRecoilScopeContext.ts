import { createContext } from 'react';

export const CompanyBoardRecoilScopeContext = createContext<string | null>(
  null,
);
