// TODO: add zod to validate that we have at least id on each object
export const useCreateOneCustomObject = ({
  _objectName,
}: {
  _objectName: string;
}) => {
  // TODO : code
};
