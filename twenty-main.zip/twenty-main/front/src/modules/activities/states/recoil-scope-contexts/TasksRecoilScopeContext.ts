import { createContext } from 'react';

export const TasksRecoilScopeContext = createContext<string | null>(null);
