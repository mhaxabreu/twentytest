import { ActivityForDrawer } from './ActivityForDrawer';

export type CommentForDrawer = NonNullable<ActivityForDrawer['comments']>[0];
