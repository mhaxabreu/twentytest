export const objectSettingsWidth = '512px';
