export enum OperationType {
  Query = 'query',
  Mutation = 'mutation',
  Subscription = 'subscription',
  Error = 'error',
}
