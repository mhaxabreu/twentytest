declare interface Window {
  FrontChat?: (method: string, ...args: any[]) => void;
}
