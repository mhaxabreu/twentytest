export enum AppBasePath {
  Auth = '/auth',
  Settings = '/settings',
  Root = '/',
}
