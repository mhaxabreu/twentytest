import { Context } from 'react';

export type RecoilScopeContext = Context<string | null>;
