export const PASSWORD_REGEX = /^.{8,}$/;
